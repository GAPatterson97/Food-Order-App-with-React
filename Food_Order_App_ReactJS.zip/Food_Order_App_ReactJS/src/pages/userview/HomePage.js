import React from "react";
import { Row, Col, Container } from "react-bootstrap";
import ItemCard from "../../components/ItemCard";
import categories from "../../categories";
import cuisines from "../../cuisines";
import restaurants from "../../restaurants";

const HomePage = () => {
  return (
    <>
      <div className="container-fluid">
        {/* Implement Task 1 - Displaying cuisine names and images */}
        <h4>Try New Cuisines</h4>
        <Container>
          <Row>
            {cuisines.map((cuisine) => (
              <Col key={cuisine.id} md={4} sm={6} lg={3}>
                <ItemCard itemName='cuisine' item={cuisine}/>
              </Col>
            ))}
          </Row>
        </Container>
      </div>
      
      <div className="container-fluid">
        {/* Implement Task 1 - Displaying category names and images */}
        <h4>Get inspiration for your order</h4>
        <Container>
          <Row>
            {categories.map((category) => (
              <Col key={category.id} md={4} sm={6} lg={3}>
                <ItemCard itemName='category' item={category}/>
              </Col>
            ))}
          </Row>
        </Container>
      </div>
      
      <div className="container-fluid">
        {/* Implement Task 1 - Displaying restaurant names and images */}
        <h4>Available restaurants</h4>
        <Container>
          <Row>
            {restaurants.map((restaurant) => (
              <Col key={restaurant.id} md={4} sm={6} lg={3}>
                <ItemCard itemName='restaurant' item={restaurant}/>
              </Col>
            ))}
          </Row>
        </Container>
      </div>
    </>
  );
};

export default HomePage;
